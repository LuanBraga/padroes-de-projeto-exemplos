﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethod
{
    //A classe "Creator" declara a fábrica de métodos que retornará
    //um objeto da classe "Produto". As subclasses de "Creator" geralmente fornecem
    //a implementação desse médodo.
    abstract class Creator
    {
        //Note que o "Creator" pode também fornercer alguma implementação padrão da Factory Method.
        public abstract IProduct FactoryMethod();

        //Observe também que, independente de seu nome, a responsabilidade do "Creator" primário
        //não é criar produtos. Geralmente, ele contém alguma lógica central de negócios que depende
        //dos objetos Produtos retornados pelo Factory Method. Subclasses podem indiretamente mudar essa
        //lógica de negócios sobrescrevendo o Factoey Method e retornando um diferente tipo de produto.
        public string SomeOperation()
        {
            //Chama o Factory Method para criar o Objeto Produto.
            var product = FactoryMethod();
            //Agora, usa o Produto.
            var result = "Creator: O mesmo código do Creator trabalhando com" + product.Operation();

            return result;
        }
    }

        //Creators Concretos sobrescrevem o Factory Method ao invés de mudar o resultado do tipo de Produto.
        class ConcreteCreator1 : Creator
        {
            //Note que a assinatura do método continua usando um tipo de produto abstrato, apesar do produto concreto ser
            //na verdade retornado pelo método. Dessa forma o Creator pode continuar indempendente da classe do produto concreto.
            public override IProduct FactoryMethod()
            {
                return new ConcreteProduct1();
            }
        }

        class ConcreteCreator2 : Creator
        {
            public override IProduct FactoryMethod()
            {
                return new ConcreteProduct2();
            }
        }

        //A interface Produto declara as operações que todos os produtos concretos devem implementar.
        public interface IProduct
        {
            string Operation();
        }

        //Produtos Concretos fornecem várias implementações da Interface Produto.
        class ConcreteProduct1 : IProduct
        {
            public string Operation()
            {
                return " {Resultado do ConcreteProduct1}";
            }
        }

        class ConcreteProduct2 : IProduct
        {
            public string Operation()
            {
                return " {Resultado do ConcreteProduct2}";
            }
        }

        class Client
        {
            public void Main()
            {
                Console.WriteLine("App: Iniciado com o ConcreteCreator1.");
                ClientCode(new ConcreteCreator1());

                Console.WriteLine("");

                Console.WriteLine("App: Iniciado com o ConcreteCreator2.");
                ClientCode(new ConcreteCreator2());

                Console.ReadLine();
            }

            //O codigo do Cliente trabalha com uma instância do Concrete Creator, embora através de sua interface base.
            //Enquanto o Client continuar trabalhando com o creator via interface base, você pode passar qualquer subclasse
            //do creator.

            public void ClientCode(Creator creator)
            {
                //..
                Console.WriteLine("Cliente: Eu não estou ciente da classe Creator," +
                    "mas tudo funciona mesmo assim.\n" + creator.SomeOperation());
                //..
            }
        }

    class Program
    {
        static void Main(string[] args)
        {
            new Client().Main();
        }
    }
}
